"""
Entry point file
"""
import decimal
import os
import sys
from typing import Any, Optional

import connexion
import orjson
import pydantic
from connexion.lifecycle import ConnexionResponse
from flask_cors import CORS
from jsonschema import ValidationError

from feature_flags.global_app import APP
from feature_flags.models import FeatureFlagsResponse
from feature_flags.utils.exceptions import FeatureFlagsException

IS_PYDOC = any(_.endswith("pydoc") for _ in sys.argv)
IS_PDOC = any(_.endswith("pdoc") for _ in sys.argv)
IS_PDOC_FORK = any(_.endswith("pydoc_fork") for _ in sys.argv)


# pylint: disable=too-few-public-methods
class ORJSONDecoder:
    """Make Json work faster
    source: https://stackoverflow.com/a/63516680/33264
    """

    def __init__(self, **kwargs: Any) -> None:
        """eventually take into consideration when deserializing"""
        self.options = kwargs

    # pylint: disable=no-self-use
    def decode(self, obj: str) -> Any:
        """decode it"""
        return orjson.loads(obj)


def default(obj: Any) -> Optional[str]:
    """Handle types json doesn't understand"""
    if isinstance(obj, decimal.Decimal):
        return str(obj)
    if isinstance(obj, pydantic.BaseModel):
        return obj.json()
    if isinstance(obj, FeatureFlagsResponse):
        return obj.json()
    return None


# pylint: disable=too-few-public-methods
class ORJSONEncoder:
    """Make Json work faster
    source: https://stackoverflow.com/a/63516680/33264
    """

    def __init__(self, **kwargs: Any) -> None:
        """eventually take into consideration when serializing"""
        self.options = kwargs

    # pylint: disable=no-self-use
    def encode(self, obj: Any) -> str:
        """decode back to str, as orjson returns bytes"""
        return orjson.dumps(obj, default=default, option=orjson.OPT_INDENT_2).decode("utf-8")


def feature_flags_exception(exception: Exception) -> ConnexionResponse:
    """Customize exceptions"""
    problem = connexion.problem(500, "User Service Error", str(exception))

    return connexion.FlaskApi.get_response(problem)


def validation_error(exception: Exception) -> ConnexionResponse:
    """Customize exceptions"""
    problem = connexion.problem(400, "Validation Error", str(exception))
    return connexion.FlaskApi.get_response(problem)


def not_implemented_error(exception: Exception) -> ConnexionResponse:
    """Customize exceptions"""
    problem = connexion.problem(501, "Not Implemented", str(exception))
    return connexion.FlaskApi.get_response(problem)


def get_env() -> str:
    """Handle errors in env name. Accept whatever because the goal is to be used
    by many applications overtime and the env names could evolve. Hard to enforce
    rules on the future."""
    start = os.environ.get("ENV", "").upper()
    if start in DOMAINS:
        return start
    synonyms = {
        "DEV": ["DEVELOPMENT", "CI", "DV"],
        "TEST": ["TESTING", "QA", "TST"],
        "STAGE": ["STAGING", "UAT", "STG"],
        "PROD": ["PRODUCTION", "PRD"],
    }
    for normal, weirds in synonyms.items():
        if start in weirds:
            return normal
    raise TypeError("Can't set CORS header, not a known environment name")


if not (IS_PYDOC or IS_PDOC or IS_PDOC_FORK):
    # How to test CORS
    # https://www.test-cors.org/
    # How to test CORS
    # https://www.test-cors.org/
    DOMAINS = {
        # chrome will ignore localhost
        "WORKSTATION": [
            "http://lvh.me",
            "http://localhost",
            "http://localhost:4201",
            "http://localhost:4200",
        ],
        # space separated domains
        "DEV": [
            "http://lvh.me http://lvh.me:4200",
            "http://lvh.me:4201",
            "http://localhost",
            "https://dev.publicrecords.usco.lctl.gov",
            "https://staff-dev.publicrecords.usco.lctl.gov",
            "https://git.loc.gov",
        ],
        "TEST": [
            "http://lvh.me http://lvh.me:4200",
            "http://lvh.me:4201",
            "http://localhost",
            "https://test.publicrecords.usco.lctl.gov",
            "https://staff-test.publicrecords.usco.lctl.gov",
            "https://git.loc.gov",
        ],
        "STAGE": [
            "https://staging.publicrecords.copyright.gov",
            "https://staff-staging.publicrecords.copyright.gov",
            "https://git.loc.gov",
        ],
        "PROD": [
            "https://publicrecords.copyright.gov",
            "https://staff.publicrecords.copyright.gov",
        ],
    }

    ENV = get_env()
    # add CORS support
    CORS_STRING = [_.strip() for _ in DOMAINS[ENV]]
    CORS(APP.app, origins=CORS_STRING)

    YAML = "api_stage.yaml" if os.environ.get("ENV") == "STAGE" else "openapi.yaml"
    YAML = "api_prod.yaml" if os.environ.get("ENV") == "PROD" else YAML
    if os.environ.get("ENV"):
        if os.environ.get("ENV") in ("DEV", "TEST", "WORKSTATION"):
            APP.add_api(YAML, strict_validation=True, validate_responses=True)
            APP.add_api(
                YAML,
                base_path="/feature_flag_service",
                strict_validation=True,
                validate_responses=True,
            )
        else:
            APP.add_api(YAML)
            APP.add_api(YAML, base_path="/feature_flag_service")

        APP.json_encoder = ORJSONEncoder
        APP.json_decoder = ORJSONDecoder
        APP.add_error_handler(FeatureFlagsException, feature_flags_exception)
        APP.add_error_handler(ValidationError, validation_error)
        APP.add_error_handler(NotImplementedError, not_implemented_error)
        FLASK_APP = APP.app

    # don't run this? If I do it just launches the dev server!
