"""
Smoke tests that run on docker run
"""
import feature_flags


def smoke_tests() -> None:
    """Really limited test.
    If this works, then docker build has a bootable OS,
    python works, venvs work, no syntax errors.
    """
    print(dir(feature_flags))
    print("Basic import works.")


# keep this, used by build script
if __name__ == "__main__":
    smoke_tests()
