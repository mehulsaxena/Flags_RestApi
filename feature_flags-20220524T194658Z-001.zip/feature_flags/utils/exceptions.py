"""
Don't throw Exception. If you do, a linter will complain.

Don't throw standard library exceptions other than ValueError and TypeError

If the error comes from this library use FeatureFlagsException

If your control flow calls for more types, subclass it here.
"""


class FeatureFlagsException(Exception):
    """
    Use this instead of raise Exception()
    """
