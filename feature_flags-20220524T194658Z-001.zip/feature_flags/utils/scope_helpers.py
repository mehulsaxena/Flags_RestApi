"""
This is so tools like vulture can tell you what is dead code (not called and not
part of the public interface, e.g. web endpoints or lambda entrypoints, etc)
"""
from functools import wraps
from typing import Any


def public_endpoint(func: Any) -> Any:
    """Just to Tag"""

    @wraps(func)
    def func_wrapper(*args: Any, **kwargs: Any) -> Any:
        """Wrapper"""
        return func(*args, **kwargs)

    return func_wrapper
