"""
Things that the python standard lib forgot
"""
import os


def locate_file(file_name: str, executing_file: str) -> str:
    """
    Find file relative to a source file, e.g.
    locate("foo/bar.txt", __file__)

    Succeeds regardless to context of execution

    File must exist
    """
    file_path = os.path.join(
        os.path.dirname(os.path.abspath(executing_file)), file_name
    )
    if not os.path.exists(file_path):
        raise TypeError(file_path + " doesn't exist")
    return file_path


def locate_folder(folder: str, executing_file: str) -> str:
    """
    Find folder relative to a source file, e.g.

    Succeeds regardless to context of execution
    """
    path = os.path.join(os.path.dirname(os.path.abspath(executing_file)), folder)
    return path


def create_file_name(file_name: str, executing_file: str) -> str:
    """
    Create a valid file name relative to a source file, e.g.
    create_file_name("foo/bar.txt", __file__)

    Succeeds regardless to context of execution

    File does not have to exist now.
    """
    return os.path.join(os.path.dirname(os.path.abspath(executing_file)), file_name)
