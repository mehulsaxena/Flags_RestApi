"""
Just the flask app, put here to avoid circular deps
and to avoid launching the webserver early when doing unit tests.
"""
import connexion

APP = connexion.FlaskApp(__name__, specification_dir=".")
