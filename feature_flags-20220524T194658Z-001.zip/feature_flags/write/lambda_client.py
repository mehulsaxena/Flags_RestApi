"""
This is called from the gitlab-ci.yml
"""
import json
import logging
import os
import pprint
from typing import Any

import botocore
import yaml
from boto_helpers.aws_lambda.lambda_actions import LambdaActions
from botocore.config import Config
from retry import retry

import feature_flags.settings as settings
from feature_flags.utils.exceptions import FeatureFlagsException
from feature_flags.write.find_files import find_files_in_environment
from feature_flags.write.yaml_validate import validate_file_name

LOGGER = logging.getLogger(__name__)


def update_database() -> None:
    """
    Invoke lambda, use key from Gitlab Env.
    """
    paths = find_files_in_environment()
    if not paths:
        LOGGER.warning("No files to process")
    errors = {}
    for file in paths:
        try:
            each_file(file)
        except FeatureFlagsException as error:
            LOGGER.warning(f"File {file} failed, going on to next")
            errors[file] = error
    if errors:
        raise FeatureFlagsException(f'{",".join(errors.keys())} failed')


def each_file(path_to_file: str) -> None:
    """Call lambda 1x per file"""
    validate_file_name(path_to_file)
    env = settings.current_env()
    patch_up_env_vars_for_credentials(env)

    # Sync calls to lambdas are some of the slowest calls because
    # we are waiting for the compute work to finish. That can be 15 minutes
    # in the worst case.
    config = Config(
        read_timeout=60 * 5, retries={"max_attempts": 5, "mode": "adaptive"}
    )
    action = LambdaActions(config=config)
    invoke_lambda(action, env, path_to_file)


# Boto has another retry algo but you have to pass a Config() to the client
@retry(
    (botocore.exceptions.ClientError), delay=1, backoff=2, max_delay=4, logger=LOGGER
)
def invoke_lambda(action: Any, env: str, path_to_file: str) -> None:
    """Just lambda invoke parts"""
    with open(path_to_file, encoding="utf-8") as file:
        result = yaml.safe_load(file)
    payload = json.dumps(result)
    lambda_name = f"{settings.PROJECT_NS}-feature-worker-{env.lower()}"
    LOGGER.info(f"Invoking {lambda_name}")
    result = action.invoke(
        function_name=lambda_name,
        payload=payload.encode(),
    )
    stream = result["Payload"]

    stream_contents = json.loads(stream.read().decode("utf-8"))
    if stream_contents == "Ok":
        LOGGER.info("Lambda invocation completed successfully")
    else:
        # if we are here, something went wrong.
        try:
            function_error = stream_contents.get("FunctionError")
        except AttributeError:
            print(stream_contents)
            raise

        if function_error == "Unhandled":
            LOGGER.error("Remote lambda finished with an unhandled exception")

        pprint.pprint(result)
        pprint.pprint(stream_contents)
        raise FeatureFlagsException("Lambda Invocation ended with unhandled exception")


def patch_up_env_vars_for_credentials(env: str) -> None:
    """Some credential management specific to public record"""
    env = env.lower()
    if env == "WORKSTATION".lower() and not settings.IS_GITLAB:
        os.environ["AWS_PROFILE"] = "copyright-public-record-development"
        if "AWS_SECRET_ACCESS_KEY" in os.environ:
            del os.environ["AWS_SECRET_ACCESS_KEY"]
        if "AWS_ACCESS_KEY_ID" in os.environ:
            del os.environ["AWS_ACCESS_KEY_ID"]
    elif env in ["DEV".lower(), "TEST".lower()]:
        if os.environ.get("AWS_DOCKER_KEY"):
            os.environ["AWS_LAMBDA_ACCESS_KEY"] = os.environ["AWS_DOCKER_KEY"]
            os.environ["AWS_LAMBDA_SECRET_KEY"] = os.environ["AWS_DOCKER_SECRET_KEY"]
    elif env in ["STAGE".lower(), "PROD".lower()]:
        if os.environ.get("AWS_DOCKER_KEY"):
            os.environ["AWS_LAMBDA_ACCESS_KEY"] = os.environ["AWS_DOCKER_KEY_STAGING"]
            os.environ["AWS_LAMBDA_SECRET_KEY"] = os.environ[
                "AWS_DOCKER_SECRET_KEY_STAGING"
            ]
    # else:
    #     raise FeatureFlagsException("Can't identify AWS key to use")


# Do not comment out, this is the main entry point for git-ops client
if __name__ == "__main__":
    # see scripts folder for a way to invoke without breaking gitlab client
    update_database()
