"""
Validate YAML file as found in the ENV var
"""
import logging
import os
from typing import Any, Optional

import yaml

from feature_flags.utils.exceptions import FeatureFlagsException
from feature_flags.write.find_files import find_files_in_environment

LOGGER = logging.getLogger(__name__)


def validate_file_name(path_to_file: str) -> str:
    """Check if file exist and is yaml"""
    if not path_to_file:
        raise FeatureFlagsException("No paths to files")

    LOGGER.info(f"Validating {os.path.basename(path_to_file)}")
    if not os.path.exists(path_to_file):
        raise FeatureFlagsException("FILE/FOLDER path doesn't resolve to a file.")
    is_yaml = path_to_file.lower().endswith("yml") or path_to_file.lower().endswith(
        "yaml"
    )
    if not is_yaml:
        raise FeatureFlagsException("FILE must have a yml or yaml extension")
    LOGGER.info(f"{os.path.basename(path_to_file)} has a name that is okay")
    return path_to_file


def validate() -> None:
    """Check if yaml file has expected parts and makes sense"""
    paths = find_files_in_environment()
    if not paths:
        LOGGER.warning("No files to validate")

    for path_to_file in paths:
        validate_file_name(path_to_file)
        with open(path_to_file, encoding="utf-8") as file:
            result = yaml.safe_load(file)
        print(result)
        validate_parsed(result)


def validate_parsed(data: Optional[dict[str, Any]]) -> None:
    """Check if a dict has right structure"""

    # TODOL Maybe replace with jsonschema or something.
    if not data:
        raise TypeError("data can't be null/falsy")
    # TODO: create a
    # import json
    # json_doc = json.dumps(result)
    problems: list[str] = []
    if "application_id" not in data:
        problems.append("Missing application_id key")

    if "default_values" not in data:
        problems.append("Missing default_values section")

    if "environment_names" not in data:
        problems.append("Missing environment_names section")

    if not isinstance(data.get("environment_names"), list):
        problems.append("Missing environment_names must be a list")

    if not data.get("environment_names", []):
        problems.append("Missing environment_names must have elements")

    if "environments" not in data:
        problems.append("Missing environments section")
    if not isinstance(data.get("environments"), dict):
        problems.append("Missing environments must be a key-value pairs")

    # pylint: disable=unused-variable
    for environment, _flags in data.get("environments", {}).items():
        if environment not in data.get("environment_names", []):
            problems.append("All environments must be listed in environment_names")

    for _environment, flag_set in data.get("environments", {}).items():
        if flag_set:
            # pylint: disable=unused-variable
            for _flag_name, flag_value in flag_set.items():
                if not isinstance(flag_value, bool):
                    problems.append("Flag values must be boolean")

    if problems:
        for problem in problems:
            LOGGER.error(problem)

        raise FeatureFlagsException("File does not validate, see log (in console)")

    LOGGER.info(f"Data appears to be okay for {data['application_id']}")


# keep this, used by gitops client
if __name__ == "__main__":
    validate()
