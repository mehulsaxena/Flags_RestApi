"""
Shared function
"""
import logging
import os
from os import listdir
from os.path import isfile, join

LOGGER = logging.getLogger(__name__)


def find_files_in_environment() -> list[str]:
    """Find files in FILE or FOLDER"""
    paths = []
    if path_to_file := os.environ.get("FILE", ""):
        paths.append(path_to_file)
    if path_to_folder := os.environ.get("FOLDER", ""):
        files = [
            _ for _ in listdir(path_to_folder) if isfile(join(path_to_folder, _)) if _
        ]
        files = [os.path.abspath(join(path_to_folder, _)) for _ in files if _]
        paths.extend(files)
    return paths
