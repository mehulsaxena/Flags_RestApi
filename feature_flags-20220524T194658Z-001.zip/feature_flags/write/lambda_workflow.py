"""Lambda Event Handler"""
import logging
from typing import Any, Optional

import feature_flags
from feature_flags.db.transactions import upsert_record
from feature_flags.utils.scope_helpers import public_endpoint
from feature_flags.write.callback_invoker import callbacks_to_clear_caches
from feature_flags.write.yaml_validate import validate_parsed

logger = logging.getLogger()
logger.setLevel(logging.INFO)

MESSAGES: list[str] = []


def inform(message: str, secret: bool = False) -> None:
    """Multiple strategies to capture what just happened"""
    if not message:
        return
    logger.info(message)
    print(message)
    if not secret:
        MESSAGES.append(str(message))


def get_temp_folder() -> str:
    """Extract so we can override this"""
    # no one else is using this lambda, nothings is going to attack the tmp folder
    # but someday we probably should just create a gist
    return "/tmp/"  # nosec


# pylint: disable=unused-argument
@public_endpoint
def lambda_handler(
    event: Optional[dict[str, Any]], context: Optional[dict[str, Any]]
) -> str:
    """Copy Yaml files to dynamodb"""
    print(event, context)
    inform(f"Executing feature_flags version {feature_flags.__version__}")
    validate_parsed(event)
    upsert_record(event)

    # This won't work anyhow, it needs to call each ECS container directly
    # or just reboot the ECS cluster.
    callbacks_to_clear_caches(event, "TODO:")
    return "Ok"
