"""
Sign endpoint
"""
import logging
import uuid
from hashlib import sha256
from hmac import new as hmac_new

import requests

# pylint: disable=line-too-long

SHARED_SECRET = b"0v2gnOBxDruE03M5HSZ691MC865953Ucdv-phkaVRmXb33hKSTq-MAh184cl5DZrTEdV__kTxHw79-wuNG25AQ"  # noqa: E501

LOGGER = logging.getLogger(__name__)


def feature_flag_callback_signed_url(nonce: str) -> str:
    """Callback to clear cache & re-query feature flag service

    Args:
        nonce (str): A guid so that these aren't all the same.

    Returns:
        str: SHA256 Cryptographic Signing Code
    """
    url = f"/FeatureFlagCallback?nonce={nonce}"
    return f"{url}&code={get_signed_url(url)}"


def get_signed_url(unsigned_endpoint: str) -> str:
    """Cryptographically sign any endpoint

    Returns:
        object:
    """
    sha256_hash_object = hmac_new(
        key=SHARED_SECRET,
        msg=str.encode(unsigned_endpoint),
        digestmod=sha256,
    )
    return sha256_hash_object.hexdigest()


def callbacks_to_clear_caches(info: dict[str, list[str]], env: str) -> None:
    """Call each app that supports callbacks.

    This will succeed even if the endpoints are failing. If the endpoints fail,
    then flags will be updated at next cache expiration.

    Returns:
        object:
    """
    key = "callbacks_to_clear_cached_flags"

    callback_list = info.get(key, {})
    if not callback_list:
        LOGGER.info("No callbacks, clients will have to get new flags by polling.")

    for _environment, domains in callback_list.items():
        if _environment != env:
            continue
        for domain in domains:
            signed_part = feature_flag_callback_signed_url(str(uuid.uuid4()))
            url = f"{domain}/{signed_part}"
            # pylint: disable=broad-except
            LOGGER.info(f"Attempting cache-busting call back to {url}")
            try:
                # long timeouts mess with lambda's
                requests.get(url, timeout=5)
                LOGGER.info(f"Succeeded calling {url}")
            except Exception as exception:  # noqa
                LOGGER.error(f"Can't call back to {url} got: {exception}")
                LOGGER.error(exception)
