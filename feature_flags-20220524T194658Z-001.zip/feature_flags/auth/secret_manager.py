"""
Purpose is to access AWS secret manager value
use get_secret("AWS secret key name", "AWS region that secret key located")
"""
import base64
from typing import Any

import boto3


def get_secret(secret_name: str, region_name: str) -> Any:
    """Get secret from AWS Secrets Manager"""
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=region_name)

    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    # let calling code decide what to do with errors.

    # Decrypts secret using the associated KMS CMK.
    if "SecretString" in get_secret_value_response:
        secret = get_secret_value_response["SecretString"]
        return secret

    decoded_binary_secret = base64.b64decode(get_secret_value_response["SecretBinary"])
    return decoded_binary_secret
