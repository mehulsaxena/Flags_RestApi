"""
Needs live AWS credentials to execute
"""
from typing import Any, cast

import orjson as json

from feature_flags.auth import secret_manager as secret_manager

SERVICE_ACCOUNT_ID = "public-record-client-web-services"
SM_AUTH_NAME_KC = "something"
SM_REGION_NAME = "us-east-1"


def get_client_secret() -> str:
    """Look up credentials in AWS"""
    secret_json = secret_manager.get_secret(SM_AUTH_NAME_KC, SM_REGION_NAME)
    sm_kc_auth_secret = json.loads(secret_json)["keycloak-auth"]
    return cast(str, sm_kc_auth_secret)


def get_live_credentials() -> dict[str, Any]:
    """Get credentials of service, not a particular user"""
    return {
        "client_id": SERVICE_ACCOUNT_ID,
        "client_secret": get_client_secret(),
        "grant_type": "client_credentials",
    }
