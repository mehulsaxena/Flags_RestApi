"""
Purpose is to get authentication token from keycloak (KC)
use get_auth_token("KC protocol", "KC hostname", "KC auth path", "KC realm",
 "relevent params")
"""
import os
from typing import Any, Union

import requests

import keycloak


class KeycloakClient:
    """Wrap up all the keycloak access"""

    def __init__(self) -> None:
        """Constructor"""
        # docs
        self.keycloak_openid = keycloak.KeycloakOpenID(  # type: ignore
            server_url="https://dev.platform.usco.lctl.gov"
            "/auth/realms/copyright/protocol/openid-connect/token",
            client_id="public-records-client",
            realm_name="copyright",
            client_secret_key=os.environ.get("client_secret_key", ""),
        )

    def login(self) -> Any:
        """Get live credentials"""
        token = self.keycloak_openid.token("user", "password")
        return token

    def user_info(self, bearer_token: str) -> Any:
        """
        from login, use: token['access_token']
        from request use Request header, "bearer"
        """
        # Get Userinfo
        user_info = self.keycloak_openid.userinfo(bearer_token)
        return user_info

    def refresh_token(self, token: dict[str, Any]) -> Any:
        """Refresh token"""
        token = self.keycloak_openid.refresh_token(token["refresh_token"])
        return token

    def logout(self, token: dict[str, Any]) -> None:
        """Logout"""
        self.keycloak_openid.logout(token["refresh_token"])

    # def other(self):
    #     # Get Certs
    #
    #     # Get RPT (Entitlement)
    #
    #     # Instropect RPT
    #         self.keycloak_openid.introspect(
    #
    #     # Introspect Token

    def verify_token(self, token: dict[str, Any]) -> Any:
        """Verify"""
        # Decode Token
        keycloak_public_key = self.keycloak_openid.public_key()
        options = {"verify_signature": True, "verify_aud": True, "verify_exp": True}
        token_info = self.keycloak_openid.decode_token(
            token["access_token"], key=keycloak_public_key, options=options
        )
        #     token["access_token"], method_token_info="decode", key=keycloak_public_key
        return token_info

    def permissions(self, token: dict[str, Any]) -> Any:
        """Get permissions by token"""
        permissions = self.keycloak_openid.get_permissions(  # nosec
            token["access_token"], method_token_info="introspect"  # nosec
        )  # nosec
        return permissions


def get_bare_bear_token(
    host_protocol: str,
    host_name: str,
    path: str,
    realm: str,
    client_params: Union[str, dict[str, Any]],
) -> Any:
    """Get a keycloak bearer token"""
    token_url = (
        f"{host_protocol}://"
        f"{host_name}{path}/realms/{realm}/protocol/openid-connect/token"
    )
    resp = requests.post(token_url, client_params, verify="https" in host_protocol)
    resp.raise_for_status()
    bearer_token = resp.json()["access_token"]
    return bearer_token


def get_auth_token(
    host_protocol: str,
    host_name: str,
    path: str,
    realm: str,
    client_params: Union[str, dict[str, Any]],
) -> dict[str, Any]:
    """Another way to get tokens"""
    bearer_token = get_bare_bear_token(
        host_protocol, host_name, path, realm, client_params
    )
    return {"Authorization": f"Bearer {bearer_token}"}
