"""
Meta data and public interface
"""

import feature_flags._version as _version

# pylint: disable=protected-access
__version__ = _version.__version__

import logging
import logging.config

from feature_flags.read.controller_utils import decode_token
from feature_flags.read.flags_api import applications, flags, flags_for_user
from feature_flags.read.utility_api import (
    environment,
    get_secret,
    secure_version,
    version,
)

LOGGER = logging.getLogger(__name__)


def configure_logging() -> None:
    """Configure logging"""
    config = {
        "version": 1,
        "handlers": {
            "console": {"class": "logging.StreamHandler", "formatter": "simple"}
        },
        "loggers": {
            "root": {
                "handlers": ["console"],
                "level": "INFO",
            },
            "feature_flags": {
                "handlers": ["console"],
                "level": "INFO",
            },
            "boto_helpers": {
                "handlers": ["console"],
                "level": "INFO",
            },
        },
        "formatters": {
            "simple": {"format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"}
        },
    }

    logging.config.dictConfig(config)


configure_logging()
LOGGER.info("Logging is enabled.")
