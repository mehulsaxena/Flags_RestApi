"""
Version file, version tracked in tag, this only tries to find
the version by package metadata. Not all code runs in a git repo,
so we can't expect a tag to always be there. ALSO, not all code
has been packaged and installed, so a version might not be there.
"""

from importlib import metadata
from importlib.metadata import PackageNotFoundError


def version_from_metadata(package: str) -> str:
    """Version comes from package"""
    try:
        return metadata.version(package)
    except PackageNotFoundError:
        return "0.0.0"


__version__ = version_from_metadata("loc_feature_flags")
# Easier to just not support pre-3.8 here than to get code coverage.
#     # Running on pre-3.8 Python; use importlib-metadata package
#
