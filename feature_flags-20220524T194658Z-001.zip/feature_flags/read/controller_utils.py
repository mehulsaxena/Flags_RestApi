"""Controllers Util generating http error message and error code

This is where you find code for handling HTTP request/response, headers,
flask, connexion related things.

This is not a dumping ground for code you can't classify. Please
put database related code in the /db/ folder, redis code in
/redis_managers/ and generic code with no domain specific content in /utils/
"""
import logging
import os
from typing import cast

from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from jose import jwt

from feature_flags import global_app
from feature_flags import settings as settings
from feature_flags.auth.secret_manager import get_secret
from feature_flags.settings import IS_GITLAB

HttpError = tuple[dict[str, object], int]

JWT_ALGORITHM = "RS256"  # "HS256"
LOGGER = logging.getLogger(__name__)


def get_safe_ip() -> str:
    """
    Check IP and don't bother with flask runtime hassles in WORKSTATION env
    """
    try:
        # pylint: disable=invalid-name
        ip = cast(str, get_remote_address())
        return ip
    except RuntimeError as error:
        if "Working outside" not in str(error):
            raise
    return ""


# None of these endpoints need to be called nonstop
def set_daily_limit() -> str:
    """Daily limit"""
    if os.environ.get("user_name") == "internal_user" or get_safe_ip().startswith(
        "140.147."
    ):
        # 200 times per second
        return f"{24 * 60 * 60 * 1000} per day"
    return f"{24 * 60 * 60} per day"


def set_hourly_limit() -> str:
    """Hourly limit"""
    if os.environ.get("user_name") == "internal_user" or get_safe_ip().startswith(
        "140.147."
    ):
        # 200 times per second
        return f"{60 * 60 * 200} per hour"
    # 1x per second
    return f"{60 * 60} per hour"


def exempt_when() -> bool:
    """When to entirely turn off rate limiting"""
    return os.environ["ENV"] in ("DEV", "dev")


DAILY_LIMIT = set_daily_limit()
HOURLY_LIMIT = set_hourly_limit()

LIMITER = Limiter(
    global_app.APP.app,
    key_func=get_remote_address,
    # 1
    default_limits=[DAILY_LIMIT, HOURLY_LIMIT],
)


def _decode_token(
    token: str, secret_bits: str, algorithm: str, verify: bool = True
) -> str:
    """More testable version of function below"""
    token = cast(
        str,
        jwt.decode(
            token,
            secret_bits,
            algorithms=[algorithm],
            audience="account",
            options={"verify_signature": verify, "verify_exp": verify},
        ),
    )
    # print(token)
    return token


def decode_token(token: str) -> str:
    """Verify and decode token"""
    # TODO: Cache this.
    verify = True
    if not IS_GITLAB:
        name = f"{settings.PROJECT_NS}-keycloak-validation-{settings.current_env().lower()}"
        key = get_secret(name, "us-east-1")
    else:
        verify = False
        key = ""

    return _decode_token(
        token,
        # settings.JWT_BITS,
        cast(str, key),
        algorithm=JWT_ALGORITHM,
        verify=verify,
    )
