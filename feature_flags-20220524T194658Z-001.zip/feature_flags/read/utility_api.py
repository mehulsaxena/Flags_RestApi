"""REST API endpoints for version, environment and other diagnostics

"""
import logging
from typing import Any, Union

import feature_flags._version as _version
from feature_flags import settings as settings

HttpError = tuple[dict[str, object], int]

LOGGER = logging.getLogger(__name__)


def get_secret(user: Any, token_info: Any) -> str:
    """Proof of concept"""
    return f"You are user_id {user} token info {token_info}."


def environment() -> Union[Any, HttpError]:
    """
    Just environment
    """
    return settings.current_env()


def version() -> Union[Any, HttpError]:
    """
    Just version
    """
    return _version.__version__


def secure_version(token_info: Any) -> Union[Any, HttpError]:
    """
    Just version, but secured.
    """
    print(f"Token info {token_info}.")
    return _version.__version__
