"""
Models to be used in openapi contracts
"""

from pydantic import BaseModel


class Flag(BaseModel):
    """Individual Flag"""

    name: str
    enabled: bool


class Metadata(BaseModel):
    """Info useful for testing, diagnostics"""

    supported_environments: list[str] = []
    """Environments that can be queried"""

    roles_considered: list[str] = []
    """Roles that user has that could have changed results"""

    identities_considered: list[str] = []
    """Identities, e.g. email address, ip address, that were considered"""

    api_version: str
    """Version of API"""


class FeatureFlagsResponse(BaseModel):
    """Response diagnostics, and two access methods, one strongly typed, one
    more convenient"""

    metadata: Metadata

    quick_flags: dict[str, bool]
    """Flags access by name"""

    feature_flags: list[Flag]
    """Flags accessed by going through list. Slower but flags can have more
    properties"""
