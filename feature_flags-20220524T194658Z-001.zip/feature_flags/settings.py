"""
Key value pairs for environment specific values.

If it is a secret, use .env. This file will exist only on workstations.
On deployment targets, actual environment variables will be set. Or we
will be using AWS Parameter Store. TBD.

If it is not a secret, use settings.ini

"""
import os

from dotenv import load_dotenv

load_dotenv()

IS_GITLAB = "GITLAB_CI" in os.environ
IS_FARGATE = os.environ.get("AWS_EXECUTION_ENV", "N/A") == "AWS_ECS_FARGATE"
IS_LAMBDA = (
    "AWS_LAMBDA_FUNCTION_NAME" in os.environ or "AWS_EXECUTION_ENV" in os.environ
)


def current_env() -> str:
    """
    Defer loading this to simplifying unit testing.
    """
    if not os.environ.get("ENV"):
        raise TypeError(
            "Need ENV to be set in environment variables."
            " No way to set a reasonable default."
        )
    return os.environ["ENV"]


_TABLE_NS_MAP = {
    "DEV": "dev",
    "TEST": "test",
    "STAGE": "stage",
    "PROD": "prod",
    # various invalid names
    "WORKSTATION": "dev",
    "DEVELOPMENT": "dev",
    "CI": "dev",
    "QA": "test",
    "UAT": "stage",
    "STAGING": "stage",
}

# prefix on dynamodb tables, etc
PROJECT_NS = "public-record"


def current_table_ns() -> str:
    """Get table ns via Lazy load env var"""
    return _TABLE_NS_MAP[current_env().upper()]
