"""
Script to make sure backup is enabled for all tables
"""
from typing import Optional

from boto3 import session as boto3_session


def enable_disable_pitr(environment: str, profile_name: Optional[str] = None) -> None:
    """Create indexes"""
    if environment not in ("dev", "test", "stage", "prod"):
        raise TypeError("Environment must be dev, test, stage or prod")
    tables = [
        f"public-record-feature-flags-{environment}",
    ]
    kwargs: dict[str, str] = {}
    if profile_name:
        kwargs["profile_name"] = profile_name
    session = boto3_session.Session(**kwargs)
    client = session.client("dynamodb")
    for table_name in tables:
        client.update_continuous_backups(
            TableName=table_name,
            PointInTimeRecoverySpecification={"PointInTimeRecoveryEnabled": True},
        )
