"""
Helper script to delete tables
"""
from feature_flags import settings
from feature_flags.db.create_tables import DynamoDBTable


def delete_all_tables(environment: str) -> None:
    """Delete all"""
    if environment not in ("dev", "test", "stage", "prod"):
        raise TypeError("Environment must be dev, test, stage or prod")
    dynamodb_table_resource = DynamoDBTable()

    table = {"TableName": f"{settings.PROJECT_NS}-feature-flags-{environment}"}
    dynamodb_table_resource.delete_table(table)
