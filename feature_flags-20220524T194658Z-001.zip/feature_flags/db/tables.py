"""Dyanmo DB table code

Returns:
    Tuple(Error message, Error code)
"""

from typing import Any, cast

import boto3.session as boto3_session
from botocore.errorfactory import ClientError

import feature_flags.settings as settings


def add_workstation_credentials(settings_module: Any) -> dict[str, Any]:
    """Hack to allow code to run on workstation"""
    kwargs = {}
    if not (
        settings_module.IS_FARGATE
        or settings_module.IS_GITLAB
        or settings_module.IS_LAMBDA
    ):
        kwargs = {"profile_name": "copyright-public-record-development"}
        # kwargs = {"profile_name": "copyright-ecs-production"}
    return kwargs


class FeatureFlagsDynamoDBTable:
    """
    Client for 'FeatureFlags' table in DynamoDB
    """

    def __init__(self, create_table: bool = False) -> None:
        """Constructor"""
        kwargs = add_workstation_credentials(settings)
        self.session = boto3_session.Session(**kwargs)
        self.client = self.session.client("dynamodb")
        self.table_name = (
            f"{settings.PROJECT_NS}-feature-flags-{settings.current_table_ns()}"
        )
        if create_table:
            self._create_table()
        self.database = self.session.resource("dynamodb")
        self.table = self.database.Table(self.table_name)

    def _create_table(self) -> None:
        """Create a table"""
        params = {
            "TableName": self.table_name,
            "AttributeDefinitions": [
                {"AttributeName": "application_id", "AttributeType": "S"},
            ],
            "KeySchema": [
                {"AttributeName": "application_id", "KeyType": "HASH"},
            ],
            "ProvisionedThroughput": {
                "ReadCapacityUnits": 10,
                "WriteCapacityUnits": 10,
            },
        }
        try:
            self.client.create_table(**params)
        except ClientError as client_error:
            if client_error.response["Error"]["Code"] == "ResourceInUseException":
                print(f"'{self.table_name}' table already exists")
            else:
                raise client_error

    @staticmethod
    def _validate_item(item: dict[str, Any]) -> bool:
        """
        Record validation stub
        """
        return bool(item)

    def add_item(self, item: dict[str, Any]) -> Any:
        """
        Insert item into the FeatureFlags table
        """
        self._validate_item(item)
        return self.table.put_item(Item=item)

    def get_all_items(
        self,
    ) -> list[dict[str, Any]]:
        """
        Return entire table. Okay if table is small.
        """
        response = self.table.scan()
        items = response["Items"]
        while "LastEvaluatedKey" in response:
            print(response["LastEvaluatedKey"])
            response = self.table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
            items.extend(response["Items"])

        return cast(list[dict[str, Any]], items)

    # TODO: Restrict the usage to 'query' using `PrimaryKey`
    def get_item(self, query: dict[str, Any]) -> dict[str, Any]:
        """
        Returns records that match the query
        """
        return cast(dict[str, Any], self.table.get_item(Key=query).get("Item", {}))

    def delete_item(self, application_id: str) -> Any:
        """Deletes record from table

        Args:
            application_id (str): Application ID, made of app + env (Primary Key)

        Returns:
            Any: Returns the delete_item response from table
        """
        return self.table.delete_item(Key={"application_id": application_id})
