"""
Set up initial schema, runs on each unit test.
"""
from typing import Any

from boto3 import session as boto3_session
from botocore.errorfactory import ClientError

from feature_flags import settings


class DynamoDBTable:
    """Table wrapper"""

    def __init__(self, profile_name: str = "") -> None:
        """Constructor"""
        kwargs: dict[str, str] = {}

        if profile_name:
            kwargs["profile_name"] = profile_name
        self.session = boto3_session.Session(**kwargs)
        self.client = self.session.client("dynamodb")

    def create_table(self, table_params: dict[str, Any]) -> None:
        """Create"""
        table_name = table_params["TableName"]
        try:
            self.client.create_table(**table_params)
        except ClientError as client_error:
            if client_error.response["Error"]["Code"] == "ResourceInUseException":
                print(f"'{table_name}' table already exists")
            else:
                raise client_error

    def update_table(self, table_params: dict[str, Any]) -> None:
        """Update"""
        table_name = table_params["TableName"]
        try:
            self.client.update_table(**table_params)
        except ClientError as client_error:
            if client_error.response["Error"]["Code"] == "ResourceInUseException":
                print(f"'{table_name}' table already exists")
            elif (
                client_error.response["Error"]["Message"]
                == "Attempting to create an index which already exists"
            ):
                print(f"'{table_name}' index already exists")
            else:
                raise client_error

    def delete_table(self, table_params: dict[str, Any]) -> None:
        """Delete a dynamodb table identified by the table_params

        Args:
            table_params (dict[str, Any]): Table params to identify a unique DynamoDB Table
        """
        if "TableName" not in table_params:
            raise KeyError("Need 'TableName' value to delete a table")
        table_name = table_params.get("TableName")
        try:
            self.client.delete_table(**table_params)
        except ClientError as client_error:
            if client_error.response["Error"]["Code"] == "ResourceNotFoundException":
                print(f"'{table_name}' table does not exist")
            else:
                raise client_error


def create_all_tables(environment: str, profile_name: str) -> None:
    """Create all"""
    if environment not in ("dev", "test", "stage", "prod"):
        raise TypeError("Environment must be dev, test, stage or prod")
    dynamodb_table_resource = DynamoDBTable(profile_name)

    table_params = {
        "TableName": f"{settings.PROJECT_NS}-feature-flags-{environment}",
        "AttributeDefinitions": [
            {"AttributeName": "application_id", "AttributeType": "S"},
        ],
        "KeySchema": [
            {"AttributeName": "application_id", "KeyType": "HASH"},
        ],
        "ProvisionedThroughput": {
            "ReadCapacityUnits": 10,
            "WriteCapacityUnits": 10,
        },
    }
    dynamodb_table_resource.create_table(table_params)
