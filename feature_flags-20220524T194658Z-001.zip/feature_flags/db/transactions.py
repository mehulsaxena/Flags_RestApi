"""
Database transactions.

CRUD for the various tables in dynamodb
"""
from typing import Any

import feature_flags.db.tables as tables


def get_record(application_id: str) -> dict[str, Any]:
    """
    Returns an item from feature flags table uniquely identified by 'application'
    """
    session = tables.FeatureFlagsDynamoDBTable()
    return session.get_item(query={"application_id": application_id})


def get_applications() -> list[str]:
    """
    Returns an item from feature flags table uniquely identified by 'application'
    """
    session = tables.FeatureFlagsDynamoDBTable()
    applications = []
    for item in session.get_all_items():
        applications.append(item["application_id"])
    return applications


# TODO: Merge this into UsersDynamoDBTable.add_user_info_item method itself
def already_exists(application_id: str) -> bool:
    """
    Returns True if a record associated with 'application_id' exists in feature flags
     table Else False
    """
    item = get_record(application_id)
    return len(item) > 0


def upsert_record(record: dict[str, Any]) -> None:
    """
    Validate and Insert record
    """
    session = tables.FeatureFlagsDynamoDBTable()
    session.add_item(record)


def delete_record(_: str) -> bool:
    """Delete the record related to 'application'

    Args:
        _ (str): user application address

    Returns:
        bool: Return True if the user exists and is deleted, Else False
    """
    raise NotImplementedError()
